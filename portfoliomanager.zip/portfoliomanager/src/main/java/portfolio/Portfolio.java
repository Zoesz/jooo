package portfolio;


import java.util.ArrayList;

public class Portfolio {
    private String name;
    private ArrayList<Position> positions;

    public Portfolio() {
        positions = new ArrayList<Position>();
    }

    public void add(Position pp1) {
        positions.add(pp1);
    }

    public String getOpenPositions() {
        for (Position position: positions) {

        }
        return this.toString();
    }

    @Override
    public String toString() {
        StringBuilder s = new StringBuilder();
        for (Position position: positions) {
            s.append(position.toString());
            s.append(" | ");
        }
        return s.toString();
    }
}