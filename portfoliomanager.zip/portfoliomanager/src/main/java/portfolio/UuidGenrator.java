package portfolio;

/**
 * Created by erikheller on 6/15/18.
 */
class UuidGenrator {
    static String get() {
        return "anyad picsaja";
    }
}
