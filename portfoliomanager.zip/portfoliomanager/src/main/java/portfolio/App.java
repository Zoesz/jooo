package portfolio;

import java.util.Date;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Portfolio p1 = new Portfolio();
        Portfolio p2 = new Portfolio();
        Position pp1 = new Position("position 1", new Date(213123213), new Date(123213213));
        Position pp2 = new Position("position 2", new Date(), new Date());
        Position pp3 = new Position("position 3", new Date(), new Date());
        p1.add(pp1);
        p1.add(pp2);
        p1.add(pp3);

        System.out.println(p1.getOpenPositions());
    }
}
