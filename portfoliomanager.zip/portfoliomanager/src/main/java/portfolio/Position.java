package portfolio;


import java.util.Date;

public class Position {
    private String name;
    private Date startDate;
    private Date endDate;
    private String uuid;

    public Position(String name, Date startDate, Date endDate) {
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
        this.uuid = UuidGenrator.get();
    }

    @Override
    public String toString() {
        return this.name;
    }
}